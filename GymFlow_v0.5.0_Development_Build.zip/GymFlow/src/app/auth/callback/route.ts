import {NextResponse,type NextRequest} from "next/server";
import {createClient} from "@/lib/supabase/server";
export async function GET(request:NextRequest){const {searchParams,origin}=new URL(request.url);const code=searchParams.get("code");const next=searchParams.get("next")??"/app";if(code){const supabase=await createClient();await supabase.auth.exchangeCodeForSession(code);}return NextResponse.redirect(new URL(next.startsWith("/")?next:"/app",origin));}
